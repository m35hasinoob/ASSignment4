import 'package:doto_manager/app.dart';

import 'package:flutter/material.dart';

void main() async {
  runApp(TaskManagerApp());
}


